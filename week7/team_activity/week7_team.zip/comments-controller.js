class CommentsController {
    constructor() {
        const myComments = JSON.parse(window.localStorage.getItem('hikeComments'));
    }

    showCommentList() {

    }
}